import { SPACES, SPACE, REAL_KEYS, ICONS } from './config.js';
import { LocalRepository } from './data/repository.js';

const repo = new LocalRepository({ spaceKeys: REAL_KEYS });
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const svg = k => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">${ICONS[k]}</svg>`;
const plural = n => `${n} élément${n > 1 ? 's' : ''}`;
const touched = x => Math.max(x.updatedAt || 0, x.viewedAt || 0);
let items = [], types = [], current, favOnly = false, editingId = null;

let tt; function toast(msg, err) { const t = $('toast'); t.textContent = msg; t.classList.toggle('error', !!err); t.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('show'), err ? 4500 : 2000); }
async function guard(fn) { try { return await fn(); } catch (e) { toast(e.message, true); } }

/* Fond immersif : teinte et cadrage suivent l'espace affiché ou survolé */
function preview(key) {
  const s = SPACE[key] || SPACE.archives, b = $('backdrop').style;
  b.setProperty('--glow', s.color); b.setProperty('--shift', s.bg[0]); b.setProperty('--lift', s.bg[1]);
  document.querySelectorAll('.tile').forEach(t => t.classList.toggle('selected', t.dataset.space === (SPACE[key] ? key : 'archives')));
}

function buildNav() {
  const all = [{ key: '', short: 'Accueil', tab: 'Accueil', color: '#9bd6a8', icon: 'home' }, ...SPACES.filter(x => !x.virtual).map(x => ({ key: x.key, short: x.nav, tab: x.short, color: x.color, icon: x.key }))];
  $('nav').innerHTML = all.map(n => `<a href="#/${n.key && 's/' + n.key}" data-k="${n.key}">${esc(n.short)}</a>`).join('');
  $('tabbar').innerHTML = all.map(n => `<a href="#/${n.key && 's/' + n.key}" data-k="${n.key}" style="--c:${n.color}">${svg(n.icon)}<span>${esc(n.tab)}</span></a>`).join('');
}
function markNav(key) { document.querySelectorAll('[data-k]').forEach(a => a.dataset.k === (key || '') ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current')); }

/* Accueil */
function renderHome() {
  $('bento').innerHTML = SPACES.map(s => {
    const n = s.virtual ? items.length : items.filter(x => x.space === s.key).length;
    return `<a class="tile ${s.cls}" href="#/s/${s.key}" data-space="${s.key}" style="--accent:${s.color}"><div class="tile-top"><div class="tile-icon">${svg(s.key)}</div><span class="pill">${esc(s.pill)}</span></div><div><h3>${esc(s.title)}</h3><p>${esc(s.tile)}</p></div><div class="tile-bottom"><span class="count">${n ? plural(n) : esc(s.empty)}</span><span class="arrow" aria-hidden="true">↗</span></div></a>`;
  }).join('');
  document.querySelectorAll('.tile').forEach(t => {
    t.addEventListener('pointerenter', e => e.pointerType === 'mouse' && preview(t.dataset.space));
    t.addEventListener('focus', () => preview(t.dataset.space));
    t.addEventListener('pointerleave', () => preview(null));
  });
  const list = [...items].sort((a, b) => touched(b) - touched(a)).slice(0, 5);
  const row = x => `<a class="recent" href="#/s/${x.space}"><div class="recent-icon" style="color:${SPACE[x.space].color}">${svg(x.space)}</div><div class="recent-main"><strong>${esc(x.title)}</strong><small>${esc(SPACE[x.space].title)} · ${esc(typeLabel(x))}</small></div>${x.status ? `<span class="tag">${esc(x.status)}</span>` : ''}</a>`;
  $('recentList').innerHTML = list.length ? list.map(row).join('') : '<div class="empty">Ton espace est prêt. Ouvre un territoire pour ajouter ta première fiche.</div>';
  const favs = items.filter(x => x.favorite).sort((a, b) => touched(b) - touched(a)).slice(0, 5);
  $('favList').innerHTML = favs.length ? favs.map(row).join('') : "<div class=\"empty\">Aucun favori pour l'instant : marque une fiche avec ★ dans son espace.</div>";
  preview(null);
}

/* Vue d'un espace */
function fillFilter(key) { $('filterStatus').innerHTML = '<option value="all">Tous les statuts</option><option value="">Sans statut</option>' + SPACE[key].statuses.map(s => `<option>${esc(s)}</option>`).join(''); }
function renderSpace() {
  const key = current, s = SPACE[key], q = $('filterInput').value.trim().toLowerCase(), st = $('filterStatus').value, ty = $('filterType').value; if (key === 'base') renderTypePanel();
  const list = items.filter(x => (key === 'all' || x.space === key) && (!favOnly || x.favorite) && (st === 'all' || x.status === st) && (ty === 'all' || x.type === ty) &&
    (!q || [x.title, x.body, x.status, typeLabel(x), x.tags.join(' '), ...Object.values(x.data)].join(' ').toLowerCase().includes(q)));
  $('itemGrid').innerHTML = list.map(x => `<article class="itemcard" style="--accent:${SPACE[x.space].color}"><div class="card-actions"><button data-fav="${x.id}" aria-pressed="${x.favorite}" aria-label="Favori : ${esc(x.title)}">${x.favorite ? '★' : '☆'}</button></div><button class="card-open" data-open="${x.id}">${thumb(x)}<strong>${esc(x.title)}</strong><p>${esc(x.body || 'Aucune description pour le moment.')}</p><small>${esc(SPACE[x.space].title)} · ${esc(typeLabel(x))}${x.status ? ' · ' + esc(x.status) : ''}</small>${meta(x)}${x.tags.length ? `<div class="tags">${x.tags.map(t => `<span>${esc(t)}</span>`).join('')}</div>` : ''}</button></article>`).join('');
  const none = $('noItems'), filtered = q || favOnly || st !== 'all';
  none.textContent = filtered ? 'Aucun élément ne correspond à cette recherche.' : 'Aucun élément ici pour le moment. Utilise « Ajouter » pour créer le premier.';
  none.classList.toggle('hidden', list.length > 0); $('itemGrid').classList.toggle('hidden', !list.length);
  $('favOnly').setAttribute('aria-pressed', favOnly);
}
function showSpace(key) {
  const s = SPACE[key]; $('homeView').classList.add('hidden'); $('detailView').classList.add('open');
  $('detailTitle').textContent = s.title; $('detailDesc').textContent = s.desc;
  const ic = $('detailIcon'); ic.innerHTML = svg(key); ic.style.cssText = `color:${s.color};border-color:${s.color}55;background:${s.color}20`;
  $('addInSpace').textContent = s.add || ''; $('addInSpace').classList.toggle('hidden', !s.add); $('filterInput').value = ''; favOnly = false; fillFilter(key); fillTypes(key); $('modPanel').classList.toggle('hidden', key !== 'systeme'); $('typePanel').classList.toggle('hidden', key !== 'base'); if (key === 'systeme') $('drawSrc').innerHTML = '<option value="all">Tous les espaces</option>' + SPACES.filter(x => !x.virtual).map(x => `<option value="${x.key}">${esc(x.title)}</option>`).join(''); $('drawOut').innerHTML = ''; renderSpace(); preview(key);
}
function showHome() { $('detailView').classList.remove('open'); $('homeView').classList.remove('hidden'); renderHome(); }
function navigate() {
  const m = location.hash.match(/^#\/s\/(\w+)/), key = location.hash === '#/reglages' ? 'reglages' : (m && SPACE[m[1]] ? m[1] : null);
  if (key === current) return; current = key;
  $('settingsView').classList.toggle('open', key === 'reglages');
  if (key === 'reglages') { $('homeView').classList.add('hidden'); $('detailView').classList.remove('open'); preview(null); }
  else key ? showSpace(key) : showHome();
  markNav(key); document.title = (key ? (SPACE[key]?.title || 'Réglages') + ' — ' : '') + 'Insula Viridis'; scrollTo(0, 0); $('main').focus({ preventScroll: true });
}
function refresh() { if (current === 'reglages') return; current ? renderSpace() : renderHome(); }
async function reload() { items = await repo.list(); types = await repo.listTypes(); refresh(); }

/* Types, champs, édition, modules */
const slug = t => t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'champ';
const typesOf = sp => sp === 'base' ? types : (SPACE[sp]?.types || []);
const typeOf = x => typesOf(x.space).find(t => t.key === x.type);
const typeLabel = x => typeOf(x)?.label || 'Sans type';
const safeUrl = u => /^https?:\/\//i.test(u || '');
const thumb = x => x.type === 'image' && safeUrl(x.data.url) ? `<img class="thumb" loading="lazy" alt="" src="${esc(x.data.url)}">` : '';
const fval = (f, v) => f.t === 'ref' ? (items.find(i => i.id === v)?.title || '') : v;
const meta = x => { const t = typeOf(x); const parts = (t?.fields || []).filter(f => f.t !== 'area' && x.data[f.k] !== undefined && fval(f, x.data[f.k]) !== '').map(f => `${esc(f.label)} : ${esc(fval(f, x.data[f.k]))}`); return parts.length ? `<div class="meta">${parts.slice(0, 3).join(' · ')}</div>` : ''; };
function fieldHtml(f, v) {
  const id = 'f_' + f.k; let c;
  if (f.t === 'list') c = `<select id="${id}"><option value="">—</option>${f.opts.map(o => `<option${o === v ? ' selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
  else if (f.t === 'ref') c = `<select id="${id}"><option value="">—</option>${items.filter(i => i.type === f.to && i.id !== editingId).map(i => `<option value="${i.id}"${i.id === v ? ' selected' : ''}>${esc(i.title)}</option>`).join('')}</select>`;
  else if (f.t === 'area') c = `<textarea id="${id}">${esc(v)}</textarea>`;
  else c = `<input id="${id}" type="${{ number: 'number', date: 'date', url: 'url' }[f.t] || 'text'}" value="${esc(v)}">`;
  return `<label>${esc(f.label)}${c}</label>`;
}
const curType = () => typesOf($('itemSpace').value).find(t => t.key === $('itemType').value);
function renderFields(data = {}) { $('fields').innerHTML = (curType()?.fields || []).map(f => fieldHtml(f, data[f.k] ?? '')).join(''); }
function readFields() { const d = {}; for (const f of curType()?.fields || []) { const v = $('f_' + f.k).value; if (v !== '') d[f.k] = f.t === 'number' ? Number(v) : v; } return d; }
function setTypes(sp, sel) { const ts = typesOf(sp); $('itemType').innerHTML = ts.map(t => `<option value="${t.key}"${t.key === sel ? ' selected' : ''}>${esc(t.label)}</option>`).join(''); $('typeRow').classList.toggle('hidden', !ts.length); }
function fillTypes(key) { const ts = key === 'all' ? [] : typesOf(key); $('filterType').innerHTML = '<option value="all">Tous les types</option>' + ts.map(t => `<option value="${t.key}">${esc(t.label)}</option>`).join(''); $('filterType').classList.toggle('hidden', !ts.length); }
function fillStatus(sp, selected = '') {
  const list = SPACE[sp].statuses, all = selected && !list.includes(selected) ? [...list, selected] : list;
  $('itemStatus').innerHTML = '<option value="">Sans statut</option>' + all.map(s => `<option${s === selected ? ' selected' : ''}>${esc(s)}</option>`).join('');
}
function openEditor(id) {
  editingId = id || null; const x = id && items.find(i => i.id === id);
  $('itemForm').reset(); $('formError').textContent = '';
  $('itemSpace').innerHTML = SPACES.filter(s => !s.virtual).map(s => `<option value="${s.key}">${esc(s.title)}</option>`).join('');
  const sp = x ? x.space : (current && current !== 'all' ? current : 'archives');
  $('itemSpace').value = sp; setTypes(sp, x?.type); fillStatus(sp, x?.status); renderFields(x?.data);
  if (x) { $('itemTitle').value = x.title; $('itemTags').value = x.tags.join(', '); $('itemBody').value = x.body; guard(async () => { await repo.update(id, { viewedAt: Date.now() }, { silent: true }); items = await repo.list(); }); }
  $('editorTitle').textContent = (x ? 'Modifier' : 'Nouvel élément') + ' — ' + SPACE[sp].title;
  $('delInEditor').classList.toggle('hidden', !x); $('editor').showModal(); $('itemTitle').focus();
}
$('itemSpace').addEventListener('change', e => { setTypes(e.target.value); fillStatus(e.target.value); renderFields(); });
$('itemType').addEventListener('change', () => renderFields());
function ask(text, ok = 'Supprimer') {
  return new Promise(res => { const d = $('confirm'); $('confirmText').textContent = text; $('confirmOk').textContent = ok; d.returnValue = ''; d.showModal(); d.addEventListener('close', () => res(d.returnValue === 'ok'), { once: true }); });
}
async function removeItem(id) {
  const x = items.find(i => i.id === id); if (!x) return;
  const refs = items.filter(i => Object.values(i.data).includes(id)).length;
  if (!await ask(`Supprimer « ${x.title} » ? Cette action est définitive.${refs ? ` Le lien depuis ${refs} autre${refs > 1 ? 's' : ''} fiche${refs > 1 ? 's' : ''} sera retiré.` : ''}`)) return;
  await guard(async () => { await repo.remove(id); await reload(); toast('Élément supprimé'); });
}
$('itemForm').addEventListener('submit', async e => {
  e.preventDefault(); $('formError').textContent = '';
  const patch = { title: $('itemTitle').value, space: $('itemSpace').value, type: $('itemType').value, data: readFields(), tags: $('itemTags').value.split(','), body: $('itemBody').value, status: $('itemStatus').value };
  try { editingId ? await repo.update(editingId, patch) : await repo.create(patch); $('editor').close(); await reload(); toast(editingId ? 'Modifications enregistrées' : 'Élément enregistré'); }
  catch (err) { $('formError').textContent = err.message; }
});
$('delInEditor').addEventListener('click', async () => { const id = editingId; $('editor').close(); await removeItem(id); });
$('cancelEditor').addEventListener('click', () => $('editor').close());

/* Base de données : types de fiches définis par l'utilisateur */
let editingType = null;
const GENRES = { nombre: 'number', date: 'date', lien: 'url', 'texte long': 'area', texte: 'text' };
const fmtField = f => `${f.label} : ${f.t === 'list' ? `liste(${f.opts.join('|')})` : f.t === 'ref' ? `relation(${f.to})` : Object.keys(GENRES).find(k => GENRES[k] === f.t)}`;
function parseFields(txt, old = []) {
  const seen = new Set();
  return txt.split('\n').map(l => l.trim()).filter(Boolean).map(l => {
    const i = l.indexOf(':'), label = (i < 0 ? l : l.slice(0, i)).trim(), spec = (i < 0 ? 'texte' : l.slice(i + 1)).trim().toLowerCase();
    let k = old.find(o => o.label.toLowerCase() === label.toLowerCase())?.k || slug(label); while (seen.has(k)) k += '_'; seen.add(k);
    const m = spec.match(/^(liste|relation)\((.*)\)$/);
    if (m) return m[1] === 'liste' ? { k, label, t: 'list', opts: m[2].split('|').map(s => s.trim()).filter(Boolean) } : { k, label, t: 'ref', to: m[2].trim() };
    if (!(spec in GENRES)) throw new Error(`Genre inconnu pour « ${label} » : ${spec}.`);
    return { k, label, t: GENRES[spec] };
  });
}
function renderTypePanel() {
  $('typePanel').innerHTML = `<div class="panelhead"><h3>Types de fiches</h3><button data-newtype>＋ Nouveau type</button></div>` + (types.length
    ? types.map(t => `<div class="recent"><div class="recent-main"><strong>${esc(t.label)} <small>(clé : ${esc(t.key)})</small></strong><small>${esc(t.fields.map(f => f.label).join(' · ') || 'Aucun champ')}</small></div><button class="ghost" data-edittype="${t.key}">Modifier</button><button class="ghost" data-deltype="${t.key}">Supprimer</button></div>`).join('')
    : '<div class="empty">Aucun type pour l\'instant. Crée par exemple « Recette » ou « Personne », avec les champs de ton choix.</div>');
}
function openType(key) {
  editingType = key || null; const t = types.find(x => x.key === key); $('typeError').textContent = '';
  $('typeName').value = t?.label || ''; $('typeFields').value = t ? t.fields.map(fmtField).join('\n') : '';
  $('typeTitle').textContent = t ? 'Modifier le type' : 'Nouveau type de fiche'; $('typeDlg').showModal(); $('typeName').focus();
}
$('typeForm').addEventListener('submit', async e => {
  e.preventDefault(); const old = types.find(t => t.key === editingType);
  try {
    const label = $('typeName').value.trim(); let key = editingType;
    if (!key) { key = slug(label); let n = 2; const base = key; while (types.some(t => t.key === key)) key = base + '_' + n++; }
    await repo.saveType({ key, label, fields: parseFields($('typeFields').value, old?.fields) });
    $('typeDlg').close(); await reload(); toast('Type enregistré');
  } catch (err) { $('typeError').textContent = err.message; }
});
$('cancelType').addEventListener('click', () => $('typeDlg').close());
async function removeType(key) {
  const t = types.find(x => x.key === key); if (!t || !await ask(`Supprimer le type « ${t.label} » ? Les fiches qui l'utilisent doivent d'abord être supprimées.`)) return;
  await guard(async () => { await repo.removeType(key); await reload(); toast('Type supprimé'); });
}
document.querySelectorAll('dialog').forEach(d => d.addEventListener('click', e => { if (e.target === d) d.close(); }));

/* Système : premier module, le tirage d'idées */
$('drawBtn').addEventListener('click', () => {
  const src = $('drawSrc').value, pool = items.filter(x => src === 'all' || x.space === src), out = $('drawOut');
  if (!pool.length) { out.innerHTML = '<div class="empty">Rien à tirer : cet espace est encore vide.</div>'; return; }
  const x = pool[Math.floor(Math.random() * pool.length)];
  out.innerHTML = `<button class="recent" data-open="${x.id}"><div class="recent-icon" style="color:${SPACE[x.space].color}">${svg(x.space)}</div><div class="recent-main"><strong>${esc(x.title)}</strong><small>${esc(SPACE[x.space].title)} · ${esc(typeLabel(x))}${x.body ? ' — ' + esc(x.body.slice(0, 110)) : ''}</small></div></button>`;
});

/* Export / import */
async function exportData() {
  await guard(async () => {
    const data = await repo.exportAll(), url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    const a = Object.assign(document.createElement('a'), { href: url, download: `insula-viridis-${new Date().toISOString().slice(0, 10)}.json` });
    document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); toast(`Sauvegarde de ${plural(data.items.length)} téléchargée`);
  });
}
$('importInput').addEventListener('change', async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  await guard(async () => {
    let data; try { data = JSON.parse(await f.text()); } catch { throw new Error("Ce fichier n'est pas un export Obsidia valide."); }
    const r = await repo.importAll(data); await reload(); toast(`${plural(r.added)} importé${r.added > 1 ? 's' : ''}${r.skipped ? `, ${r.skipped} ignoré${r.skipped > 1 ? 's' : ''}` : ''}`);
  });
});

/* Événements globaux */
document.addEventListener('click', e => {
  const b = e.target.closest('[data-open],[data-fav],[data-del],[data-newtype],[data-edittype],[data-deltype]'); if (!b) return;
  if (b.dataset.newtype !== undefined) openType(); else if (b.dataset.edittype) openType(b.dataset.edittype); else if (b.dataset.deltype) removeType(b.dataset.deltype);
  else if (b.dataset.open) openEditor(b.dataset.open);
  else if (b.dataset.del) removeItem(b.dataset.del);
  else { const x = items.find(i => i.id === b.dataset.fav); guard(async () => { await repo.update(x.id, { favorite: !x.favorite }, { silent: true }); await reload(); }); }
});
function globalSearch() { const f = $('filterInput'); if (f.offsetParent) f.focus(); }
document.addEventListener('keydown', e => {
  const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) || document.querySelector('dialog[open]');
  if ((e.key === '/' && !typing) || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k')) { e.preventDefault(); globalSearch(); }
});
$('addInSpace').addEventListener('click', () => openEditor());
$('filterType').addEventListener('change', renderSpace);
$('exportBtn').addEventListener('click', exportData);
$('importBtn').addEventListener('click', () => $('importInput').click());
$('filterInput').addEventListener('input', renderSpace); $('filterStatus').addEventListener('change', renderSpace);
$('favOnly').addEventListener('click', () => { favOnly = !favOnly; renderSpace(); });
addEventListener('hashchange', navigate);

/* Démarrage : chargement, puis erreur lisible si le stockage est inaccessible */
buildNav();
try { items = await repo.list(); types = await repo.listTypes(); }
catch (e) { $('recentList').innerHTML = `<div class="empty" role="alert">${esc(e.message)}</div>`; items = []; }
navigate();
