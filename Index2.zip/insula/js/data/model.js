// Format des données + migrations. Toute évolution du format = une étape de plus dans `steps`.
export const CURRENT_VERSION = 1;
export const STORAGE_KEY = 'insula:v1';
export const uid = () => globalThis.crypto?.randomUUID?.() ?? Date.now().toString(36) + Math.random().toString(36).slice(2, 9);

export function makeItem(p = {}, now = Date.now()) {
  return {
    id: p.id || uid(), space: p.space, type: p.type || '', title: String(p.title ?? '').trim(), body: String(p.body ?? ''),
    tags: [...new Set((Array.isArray(p.tags) ? p.tags : []).map(t => String(t).trim()).filter(Boolean))],
    status: p.status || '', favorite: !!p.favorite,
    data: p.data && typeof p.data === 'object' ? p.data : {}, // valeurs des champs du type (clé = clé du champ)
    createdAt: p.createdAt || now, updatedAt: p.updatedAt || now, viewedAt: p.viewedAt || null,
  };
}
export function validate(item, spaceKeys) {
  if (!item.title) throw new Error('Le titre est obligatoire.');
  if (!spaceKeys.includes(item.space)) throw new Error('Espace inconnu : ' + item.space);
}
export function validateType(t) {
  if (!t || !/^[a-z0-9_]+$/.test(t.key || '') || !String(t.label || '').trim() || !Array.isArray(t.fields)) throw new Error('Type de fiche invalide.');
}
const steps = {}; // ex. futur : steps[1] = ({items, types}) => ({ items: items.map(...), types })

export function migrate(raw) {
  let version = raw?.version ?? 1, items = raw?.items ?? [], types = raw?.types ?? [];
  if (!Array.isArray(items) || !Array.isArray(types)) throw new Error('Format de données invalide.');
  if (version > CURRENT_VERSION) throw new Error("Ces données viennent d'une version plus récente d'Insula Viridis.");
  while (version < CURRENT_VERSION) { ({ items, types } = steps[version]({ items, types })); version++; }
  return { version, items, types };
}
