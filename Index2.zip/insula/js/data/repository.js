// Seul point d'accès aux données. Aujourd'hui : stockage du navigateur.
// Étape suivante : SupabaseRepository avec les mêmes méthodes, sans toucher à l'interface.
import { CURRENT_VERSION, STORAGE_KEY, migrate, makeItem, validate, validateType } from './model.js';
const EDITABLE = ['space', 'type', 'title', 'body', 'tags', 'status', 'favorite', 'data', 'viewedAt'];

export class LocalRepository {
  constructor({ storage = globalThis.localStorage, spaceKeys = [] } = {}) { this.storage = storage; this.spaceKeys = spaceKeys; this.db = null; }
  _load() {
    if (this.db) return this.db;
    const raw = this.storage.getItem(STORAGE_KEY);
    try { this.db = raw === null ? { version: CURRENT_VERSION, items: [], types: [] } : migrate(JSON.parse(raw)); }
    catch (e) { throw new Error("Données illisibles (" + e.message + "). Rien n'a été écrasé."); }
    return this.db;
  }
  _save() {
    try { this.storage.setItem(STORAGE_KEY, JSON.stringify(this.db)); }
    catch { this.db = null; throw new Error("Enregistrement impossible : stockage du navigateur plein ou bloqué. Exporte tes données."); }
  }
  async list() { return structuredClone([...this._load().items].sort((a, b) => b.updatedAt - a.updatedAt)); }
  async listTypes() { return structuredClone(this._load().types); }
  async create(p) { const db = this._load(), it = makeItem(p); validate(it, this.spaceKeys); db.items.unshift(it); this._save(); return structuredClone(it); }
  async update(id, patch, { silent = false } = {}) {
    const db = this._load(), it = db.items.find(x => x.id === id);
    if (!it) throw new Error('Élément introuvable (déjà supprimé ?).');
    const next = makeItem({ ...it, ...Object.fromEntries(Object.entries(patch).filter(([k]) => EDITABLE.includes(k))) });
    validate(next, this.spaceKeys); Object.assign(it, next, { updatedAt: silent ? it.updatedAt : Date.now() });
    this._save(); return structuredClone(it);
  }
  async remove(id) {
    const db = this._load(), n = db.items.length;
    db.items = db.items.filter(x => x.id !== id);
    if (db.items.length === n) throw new Error('Élément introuvable (déjà supprimé ?).');
    for (const it of db.items) for (const [k, v] of Object.entries(it.data)) if (v === id) delete it.data[k]; // relations : pas de lien orphelin
    this._save();
  }
  async saveType(t) {
    validateType(t); const db = this._load(), i = db.types.findIndex(x => x.key === t.key);
    i < 0 ? db.types.push(t) : (db.types[i] = t); this._save();
  }
  async removeType(key) {
    const db = this._load(), n = db.items.filter(i => i.type === key).length;
    if (n) throw new Error(`${n} fiche${n > 1 ? 's utilisent' : ' utilise'} encore ce type : supprime-les ou change leur type d'abord.`);
    db.types = db.types.filter(t => t.key !== key); this._save();
  }
  async exportAll() { const db = this._load(); return { app: 'insula-viridis', version: CURRENT_VERSION, exportedAt: new Date().toISOString(), items: structuredClone(db.items), types: structuredClone(db.types) }; }
  async importAll(data) {
    const m = migrate(data), db = this._load(); let added = 0, skipped = 0;
    for (const t of m.types) { try { validateType(t); if (!db.types.some(x => x.key === t.key)) db.types.push(t); } catch { skipped++; } }
    for (const raw of m.items) {
      try {
        const it = makeItem(raw); validate(it, this.spaceKeys); const i = db.items.findIndex(x => x.id === it.id);
        if (i === -1) { db.items.push(it); added++; } else if (it.updatedAt > db.items[i].updatedAt) { db.items[i] = it; added++; }
      } catch { skipped++; }
    }
    this._save(); return { added, skipped };
  }
}
