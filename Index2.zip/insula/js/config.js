// Source unique des espaces : identité, couleurs, statuts et types de fiches par défaut.
// Les types de la Base de données sont créés par l'utilisateur et stockés avec ses données.
export const ICONS={"home": "<path d=\"M3 11 12 3l9 8M5 10v10h5v-6h4v6h5V10\"/>", "archives": "<path d=\"M5 4h14v4H5zM6 8v12h12V8M10 12h4\"/>", "atelier": "<path d=\"m4 20 4-1 11-11-3-3L5 16zM14 6l3 3\"/>", "bibliotheque": "<path d=\"M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11\"/>", "systeme": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"m15.5 8.5-2 5-5 2 2-5z\"/>", "base": "<ellipse cx=\"12\" cy=\"5\" rx=\"8\" ry=\"3\"/><path d=\"M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3\"/>", "all": "<path d=\"M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z\"/>"};
export const SPACES=[
{
"key": "archives", "add": "＋ Note, lien ou image",
"cls": "archive",
"title": "Archives personnelles",
"short": "Archives",
"nav": "Archives",
"desc": "Notes, liens, images et fragments à garder librement.",
"tile": "Ce que tu veux garder, sans avoir à le classer.",
"color": "#9bd6a8",
"pill": "Collecter",
"empty": "Collection libre",
"bg": [
"0px",
"0px"
],
"statuses": [
"À explorer",
"En cours",
"Terminé",
"À développer",
"Archivé"
],
"types": [
{
"key": "note",
"label": "Note",
"fields": []
},
{
"key": "lien",
"label": "Lien",
"fields": [
{
"k": "url",
"label": "Adresse",
"t": "url"
}
]
},
{
"key": "image",
"label": "Image",
"fields": [
{
"k": "url",
"label": "Adresse de l'image",
"t": "url"
}
]
}
]
},
{
"key": "atelier", "add": "＋ Fiche créative",
"cls": "studio",
"title": "Atelier de création",
"short": "Atelier",
"nav": "Atelier",
"desc": "Projets indépendants : histoires, personnages, lieux, scènes et règles d'univers.",
"tile": "Histoires, univers et personnages en construction.",
"color": "#e8a5b4",
"pill": "Imaginer",
"empty": "Espace créatif",
"bg": [
"-70px",
"-14px"
],
"statuses": [
"À explorer",
"En cours",
"Terminé",
"À développer",
"Archivé"
],
"types": [
{
"key": "projet",
"label": "Projet",
"fields": [
{
"k": "genre",
"label": "Genre",
"t": "text"
},
{
"k": "resume",
"label": "Résumé",
"t": "area"
}
]
},
{
"key": "personnage",
"label": "Personnage",
"fields": [
{
"k": "projet",
"label": "Projet",
"t": "ref",
"to": "projet"
},
{
"k": "role",
"label": "Rôle",
"t": "text"
}
]
},
{
"key": "lieu",
"label": "Lieu",
"fields": [
{
"k": "projet",
"label": "Projet",
"t": "ref",
"to": "projet"
}
]
},
{
"key": "scene",
"label": "Scène",
"fields": [
{
"k": "projet",
"label": "Projet",
"t": "ref",
"to": "projet"
},
{
"k": "ordre",
"label": "Ordre",
"t": "number"
}
]
},
{
"key": "regle",
"label": "Règle d'univers",
"fields": [
{
"k": "projet",
"label": "Projet",
"t": "ref",
"to": "projet"
}
]
}
]
},
{
"key": "bibliotheque", "add": "＋ Œuvre",
"cls": "library",
"title": "Bibliothèque de contenus",
"short": "Biblio.",
"nav": "Bibliothèque",
"desc": "Mangas, animés, films, séries, livres, jeux : ce que tu découvres et suis.",
"tile": "Œuvres, lectures et découvertes.",
"color": "#6cc4cf",
"pill": "Découvrir",
"empty": "Ta collection",
"bg": [
"60px",
"-8px"
],
"statuses": [
"À découvrir",
"En cours",
"Terminé",
"Abandonné"
],
"types": [
{
"key": "manga",
"label": "Manga",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
},
{
"key": "anime",
"label": "Animé",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
},
{
"key": "film",
"label": "Film",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
},
{
"key": "serie",
"label": "Série",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
},
{
"key": "livre",
"label": "Livre",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
},
{
"key": "jeu",
"label": "Jeu vidéo",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
},
{
"key": "doc",
"label": "Documentaire",
"fields": [
{
"k": "note",
"label": "Note /10",
"t": "number"
},
{
"k": "progression",
"label": "Progression",
"t": "text"
},
{
"k": "lien",
"label": "Lien",
"t": "url"
}
]
}
]
},
{
"key": "systeme", "add": "＋ Règle, idée ou module",
"cls": "system",
"title": "Mon propre système",
"short": "Système",
"nav": "Système",
"desc": "Règles, idées d'outils et modules que tu construis. Le tirage d'idées est le premier module.",
"tile": "Tes outils, règles et expériences.",
"color": "#d4e08a",
"pill": "Construire",
"empty": "Atelier ouvert",
"bg": [
"-30px",
"10px"
],
"statuses": [
"À explorer",
"En cours",
"Terminé",
"À développer",
"Archivé"
],
"types": [
{
"key": "regle",
"label": "Règle",
"fields": []
},
{
"key": "outil",
"label": "Idée d'outil",
"fields": []
},
{
"key": "module",
"label": "Module",
"fields": []
}
]
},
{
"key": "base", "add": "＋ Fiche",
"cls": "database",
"title": "Base de données",
"short": "Base",
"nav": "Base de données",
"desc": "Tes propres types de fiches, avec les champs et les relations que tu définis.",
"tile": "Fiches sur mesure, champs et relations.",
"color": "#e6bf7a",
"pill": "Structurer",
"empty": "Ton architecture",
"bg": [
"40px",
"16px"
],
"statuses": [
"À explorer",
"En cours",
"Terminé",
"À développer",
"Archivé"
],
"types": []
},
{
"key": "all",
"cls": "extra",
"title": "Tous les éléments",
"short": "Tout",
"nav": "Tout",
"desc": "Tout ce que tu as créé, au même endroit.",
"tile": "Retrouver n'importe quoi, partout dans l'île.",
"color": "#b9c9bd",
"pill": "Transversal",
"empty": "Vue globale",
"bg": [
"0px",
"0px"
],
"statuses": [
"À explorer",
"En cours",
"Terminé",
"À développer",
"Archivé",
"À découvrir",
"Abandonné"
],
"virtual": true,
"types": []
}
];
export const SPACE=Object.fromEntries(SPACES.map(s=>[s.key,s]));
export const REAL_KEYS=SPACES.filter(s=>!s.virtual).map(s=>s.key);
