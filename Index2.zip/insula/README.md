# Insula Viridis — v0.2 (une action = un seul endroit)

## Lancer
Aucune installation ni compilation. Les modules ES demandent un petit serveur local :

    cd insula
    python3 -m http.server 8123     # ou : npx serve .
    # puis ouvrir http://localhost:8123

Tests des données (Node 18+) : `node --test test/data.test.mjs`

## Arborescence
    index.html              page, fond « île », fenêtres (élément, type de fiche, confirmation)
    css/styles.css          identité visuelle (palette forêt, serif, courbes de niveau, mobile)
    js/config.js            les cinq espaces : couleurs, icônes, statuts, types et champs par défaut
    js/data/model.js        format des données + migrations (version 1)
    js/data/repository.js   SEUL accès aux données (stockage navigateur). À remplacer pour la synchro
    js/app.js               interface : routes, rendu, formulaires dynamiques, types, module, export/import
    test/data.test.mjs      tests de la couche de données

## Ce qui existe dans chaque espace
- Archives : notes, liens, images (miniature si l'adresse est http/https).
- Atelier : projets, personnages, lieux, scènes, règles d'univers ; chaque fiche peut pointer vers un projet.
- Bibliothèque : manga, animé, film, série, livre, jeu, documentaire ; statuts À découvrir/En cours/Terminé/Abandonné ; note et progression facultatives.
- Système : règles, idées d'outils, modules ; premier module = tirage d'idées au hasard.
- Base de données : types de fiches créés par toi (champs texte, texte long, nombre, date, lien, liste, relation vers un autre type).
- Partout : recherche, filtres type/statut/favoris, étiquettes, modification, suppression confirmée, export/import JSON.

## Limites actuelles (à lire)
- Données stockées dans CE navigateur uniquement : pas de compte, pas de synchro, aucune protection d'accès.
  Exporter régulièrement (bouton « Exporter (JSON) »).
- Les types par défaut des quatre premiers espaces se modifient dans js/config.js, pas encore dans l'interface.
- Renommer un champ d'un type crée un nouveau champ : l'ancienne valeur reste stockée mais n'est plus affichée.
- Pas de fichiers/images téléversés : seulement des adresses web.
- Pas de personnalisation des couleurs, icônes, raccourcis ni dispositions depuis l'interface.

## Étape suivante : synchro + connexion (non faite)
Plan : Supabase (connexion + base Postgres avec règles d'accès par utilisateur, inscriptions publiques désactivées),
un `SupabaseRepository` aux mêmes méthodes que `LocalRepository`, hébergement statique (Cloudflare Pages/Netlify).
Rien de cela n'est branché dans cette version.

## Tests manuels conseillés
Créer un projet puis un personnage lié ; supprimer le projet (message de lien retiré) ; créer un type « Recette » puis une fiche ;
ajouter un champ au type et vérifier que la fiche garde ses valeurs ; tirage d'idées ; export puis import ; recharger ; clavier (Tab, Échap, touche /) ; téléphone.

## Règle d'interface (v0.2)
Chaque action n'existe qu'à un seul endroit :
- Création : uniquement dans l'espace concerné (bouton « Ajouter » propre à chaque espace). Pas de création depuis l'accueil ni depuis « Tout ».
- Suppression : uniquement dans la fiche ouverte. Favori : uniquement sur la carte.
- Export / import : uniquement dans Réglages (icône ⚙ en haut à droite).
- Recherche et filtres : dans chaque espace ; « Tout » sert à chercher dans l'ensemble.
- L'accueil ne contient que de la navigation (territoires, récents, favoris).
- Retiré volontairement : changer une fiche d'espace (déplacement) ; elle reste dans son espace d'origine.
