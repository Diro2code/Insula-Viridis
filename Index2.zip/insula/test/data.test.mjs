import test from 'node:test'; import assert from 'node:assert/strict';
import { LocalRepository } from '../js/data/repository.js';
const KEYS = ['archives', 'atelier', 'bibliotheque', 'systeme', 'base'];
const mem = (init = {}, quota = Infinity) => { const m = { ...init }; return { getItem: k => k in m ? m[k] : null, setItem: (k, v) => { if (v.length > quota) throw new Error('quota'); m[k] = v; }, m }; };
const mk = s => new LocalRepository({ storage: s, spaceKeys: KEYS });

test('CRUD ; le favori silencieux ne change pas updatedAt', async () => {
  const r = mk(mem()); const c = await r.create({ title: ' Note ', space: 'atelier', tags: ['a', 'a', ' b '] });
  assert.equal(c.title, 'Note'); assert.deepEqual(c.tags, ['a', 'b']);
  const u = await r.update(c.id, { favorite: true }, { silent: true }); assert.equal(u.updatedAt, c.updatedAt);
  await r.update(c.id, { title: 'Nouveau' }); assert.equal((await r.list())[0].title, 'Nouveau');
  await r.remove(c.id); assert.equal((await r.list()).length, 0); await assert.rejects(r.remove(c.id), /introuvable/);
});
test('validation : titre vide et espace inconnu refusés', async () => {
  const r = mk(mem()); await assert.rejects(r.create({ title: ' ', space: 'archives' }), /titre/); await assert.rejects(r.create({ title: 'x', space: 'zzz' }), /Espace/);
});
test('types : création, modification sans perte de données, suppression refusée tant que utilisés', async () => {
  const r = mk(mem()); await r.saveType({ key: 'recette', label: 'Recette', fields: [{ k: 'temps', label: 'Temps', t: 'number' }] });
  const it = await r.create({ title: 'Tarte', space: 'base', type: 'recette', data: { temps: 40 } });
  await r.saveType({ key: 'recette', label: 'Recettes', fields: [{ k: 'temps', label: 'Temps', t: 'number' }, { k: 'four', label: 'Four', t: 'text' }] });
  assert.equal((await r.list())[0].data.temps, 40); assert.equal((await r.listTypes())[0].fields.length, 2);
  await assert.rejects(r.removeType('recette'), /utilise encore/); await r.remove(it.id); await r.removeType('recette'); assert.equal((await r.listTypes()).length, 0);
  await assert.rejects(r.saveType({ key: 'Bad Key', label: 'x', fields: [] }), /invalide/);
});
test('relations : supprimer une fiche retire les références vers elle', async () => {
  const r = mk(mem()); const p = await r.create({ title: 'Projet A', space: 'atelier', type: 'projet' });
  const c = await r.create({ title: 'Héros', space: 'atelier', type: 'personnage', data: { projet: p.id, role: 'lead' } });
  await r.remove(p.id); const [h] = await r.list(); assert.equal(h.id, c.id); assert.deepEqual(h.data, { role: 'lead' });
});
test('stockage plein : erreur claire, pas de donnée fantôme', async () => {
  const r = mk(mem({}, 5)); await assert.rejects(r.create({ title: 'x', space: 'archives' }), /Enregistrement impossible/); assert.equal((await r.list()).length, 0);
});
test("données corrompues : erreur, rien n'est écrasé", async () => {
  const s = mem({ 'insula:v1': '{pas du json' }); await assert.rejects(mk(s).list(), /illisibles/); assert.equal(s.m['insula:v1'], '{pas du json');
});
test('export/import : fusion par id, types inclus, invalides ignorés, version future refusée', async () => {
  const a = mk(mem()); await a.saveType({ key: 't', label: 'T', fields: [] }); await a.create({ title: 'A', space: 'base', type: 't' }); const dump = await a.exportAll();
  const b = mk(mem()); assert.deepEqual(await b.importAll(dump), { added: 1, skipped: 0 }); assert.equal((await b.listTypes()).length, 1);
  assert.deepEqual(await b.importAll(dump), { added: 0, skipped: 0 });
  dump.items.push({ id: 'bad', title: '', space: 'base' }); assert.equal((await b.importAll(dump)).skipped, 1);
  await assert.rejects(b.importAll({ version: 99, items: [] }), /plus récente/);
});
